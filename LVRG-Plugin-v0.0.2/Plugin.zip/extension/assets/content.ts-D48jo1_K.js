const e="/assets/main.tsx-wc8GU66v.js",t=document.createElement("script");t.type="module";t.src=chrome.runtime.getURL(e);document.body.appendChild(t);
